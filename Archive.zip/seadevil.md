---
title: Sea Devil
permalink: /seadevil/
---
This sculpture combines the form of an angler fish with casts of my hand and fingers. It's made of painted plaster and foam, with a functioning light.

![seadevil_1](/img/seadevil/seadevil_1.jpg){: .center}

![seadevil_2](/img/seadevil/seadevil_2.jpg){: .center}

![seadevil_3](/img/seadevil/seadevil_3.jpg){: .center}
