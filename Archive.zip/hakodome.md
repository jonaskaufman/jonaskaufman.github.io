---
title: Hakodome
permalink: /hakodome/
---

This nightstand features six traditional Japanese _hakodome_, or rabbeted tenoned miter joints. The frame is mahogany with a walnut top held up by ebony tenons. The front face pulls out to reveal a drawer with hand-cut dovetails.

![final_1](/img/hakodome/final_iso_closed.jpg){: .center}

![final_2](/img/hakodome/final_front.jpg){: .center}

![final_3](/img/hakodome/final_detail.jpg){: .center}

![build_1](/img/hakodome/build_1.jpg){: .center}

![build_2](/img/hakodome/build_2.jpg){: .center}

![build_3](/img/hakodome/build_3.jpg){: .center}
