---
title: Contact
permalink: /contact/
---

Want to get in touch? Send me an email at <a href="mailto:jonas.l.kaufman@gmail.com">jonas.l.kaufman@gmail.com</a>. 

You can also find me on [Facebook](https://www.facebook.com/jonas.kaufman) or [LinkedIn](https://www.linkedin.com/in/jonaskaufman).
