---
title: About
permalink: /about/
---

I'm a senior physics major at [Harvey Mudd College](http://hmc.edu) in Claremont, CA. I'm interested in materials engineering and computational modelling for advanced energy applications.

![me](/img/me.jpg){: .center}

Outside of my studies, I enjoy woodworking, Brazilian Jiu Jitsu, running, hiking, and making music.

View my resume [here](/files/jlk_resume.pdf)
