---
title: Figurines
permalink: /figurines/
---
These are some wooden figurines I've carved. I use and highly recommend [this book](http://www.amazon.com/Technique-Scandinavian-Style-Woodcarving-Step-Step/dp/1565232305) for instructions and ideas.

![bear](/img/figurines/bear_1.jpg){: .center}
Bear
{: style="text-align: center"}

![captain](/img/figurines/captain_1.jpg){: .center}
Sea Captain
{: style="text-align: center"}
